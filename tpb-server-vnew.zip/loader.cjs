import('./index.js').catch(err => {
  console.error('Error loading ES Module:', err);
});
